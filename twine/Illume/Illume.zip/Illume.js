window.onload = function() {
	if (typeof(window.Illume) == "undefined") {
	
	
		window.Illume = {

			init: function() { 				
				Illume.UI.init();
				Illume.Editor.init();
				Illume.Diff.init();
				Illume.Story.init();
				Illume.Passages.init();
				Illume.Overview.init();

				this.UI.updateList();
				this.Overview.showStoryOverview();

			},
		
		
			popout:	function(content) {
				var w = window.open();
				w.document.write(content);
			},
			
			download:	function(filename, text, contentType) {
				if (!contentType)
					contentType = 'text/plain';
				
				window.URL = window.URL || window.webkitURL;
				var dataBlob = new Blob([text], {type: contentType});
				
				var downloader = document.createElement('a');
				downloader.setAttribute('innerHtml', 'downloader');
				downloader.setAttribute('href', window.URL.createObjectURL(dataBlob));
				downloader.setAttribute('download', filename);
				downloader.onclick = function() {
					document.body.removeChild(event.target);
				};
				document.body.appendChild(downloader);
				downloader.click();
			},
			
			viewChangeList:	function() {
				this.generateChangeList(false);
			},
			
			saveChangeList:	function() {
				this.generateChangeList(true);				
			},
			
			generateChangeList:	function(forExport) {
				var buffer = [];
				var diffs;
				var p;

				var matches = Illume.Passages.findPassages(function(p) { return p.changed;});
				var title = Illume.Story.storyName + ' Change List - ' + (new Date()).toLocaleString();
				
				if (matches.length < 1) {
					alert('No changes have been made.');
					return '';
				}

				buffer.push('<html><he','ad>');
				buffer.push('<title>',title,'</title>');
				buffer.push('<style type="text/css">');
				buffer.push('ins {background: #9f9;} del {background: #f99;}');
				buffer.push("body{font-family:'Open Sans','Source Code Pro','Deja Vu Sans','Arial',sans-serif;}");
				buffer.push("h1{text-align:center;}");
				buffer.push("h2{margin:50px 0px 0px 10px;}");
				buffer.push("input{float:right;}");
				buffer.push("pre{margin: 0px;line-height: 175%;font-size: 12pt;border: solid #999;border-width: 1px 0px 1px 0px;}");
				buffer.push('</style>');
				buffer.push('</he','ad><bo','dy>');

				buffer.push('<h1>', title, '</h1>');
				
				for (var i in matches) {
					p = matches[i];
					diffs = window.Illume.Diff.diff(this.encodeEntities(p.originalContent), this.encodeEntities(p.content));
					
					buffer.push('<div id="p.' + p.id + '">');
					buffer.push('<input type="button" value="Done" onclick="this.parentNode.remove(this);" />');
					buffer.push("<h2>", p.name, "</h2>");
					buffer.push("<pre>", window.Illume.Diff.formatDiffs(diffs),"</pre>");
					buffer.push("</div>");
				}
				
				buffer.push('</bo', 'dy></html>');
				
				var output = buffer.join('');
				
				if (forExport) {
					this.download(title + '.html', output, 'text/html');
				} else {
					this.popout(output);
				}
				
			},
			
			encodeEntities:	function(s) {
				return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
			},
			
			exportTwee: function() {
				this.download(Illume.Story.storyName + ".tw", Illume.Entweedle.export(), 'text/plain');
			},

			saveToFile:	function() {
				alert("Note: the saved file will be a fresh copy of this illumination and will not include any changes you've made to this version.");
				this.download(Illume.Story.storyName + " (Illuminated).html", window.document.documentElement.innerHTML, 'text/html');
			}
		
		
		}
	
	
		window.Illume.Overview = {
			introText: '',
			tips: '',
			
			init:	function() {
				this.introText = window.document.getElementById('introText').innerHTML;
				this.tips = window.document.getElementById('tips').innerHTML;
			},
		
			showStoryOverview:	function() {
				Illume.Story.compileStats();
				
				var buffer = [];
				
				buffer.push(this.generateTile("Welcome to Illume", Illume.Overview.introText,'2x1'));
				buffer.push(this.generateTile("Stats", this.generateTable(Illume.Story.generateStorySummary()) + '<p>These do not reflect changes made during review or by macros during play.</p>'));
				buffer.push(this.generateTile("Review Summary", this.generateTable(Illume.Passages.generateReviewSummary())));

				buffer.push(this.generateTile("Passage Summary", this.generateTable(Illume.Passages.generateSummary()),'2x1'));
				buffer.push(this.generateTile("Tags", this.generateTable(Illume.Story.getTagSummary(), true),'1x1'));

				buffer.push(this.generateTile("Tips", Illume.Overview.tips));
				
								
				Illume.UI.showGeneralOutput('Story Overview', buffer.join(''));
			},
		
			generateTile:	function(title,content,size,classes) {
				var buffer = [];
				if (!size)
					size = '1x1';
				
				buffer.push('<div class="infoTile tile', size, ' ', classes, '"><div class="title">');
				buffer.push(title);
				buffer.push('</div><div class="content">');
				buffer.push(content);
				buffer.push('</div></div>');
				
				return buffer.join('');
			},
			
			generateTable:	function(o, preserveLabels) {
				var label,link,data;
				var buffer = [];
				var isHeader = false;
				
				buffer.push("<table>");
				for (key in o) {
					label = key;
					
					if (label.indexOf("header.") > -1) {
						label = label.substring(7);
						isHeader = true;
					} else {
						isHeader = false
					}
					
					
					if (!preserveLabels) {
						label = label.replace(/[A-Z][a-z]*/g, function(word) { return ' ' + word.charAt(0).toUpperCase() + word.substr(1);});
						label = label.charAt(0).toUpperCase() + label.substr(1);
					}
					
					data = o[key];
					
					link = data['illumeLink'];
				
					buffer.push("<tr");
					if (isHeader) {
						buffer.push(' class="header"');
					}
					buffer.push("><td>");
					if (link && link.length > 0) {
						buffer.push('<span class="link" onclick="' + link + '">');
					}
					buffer.push(label);
					if (link) {
						buffer.push('</span>');
					}
					buffer.push("</td>");
					if (typeof data == "object") {
						for (var i in data) {
							if (i == 'illumeLink')
								continue;
								
							buffer.push('<td>', data[i], '</td>');
						}
					} else {
						buffer.push('<td>', data, '</td>')
					}
					buffer.push("</tr>");
				}
				buffer.push("</table>");
				
				return buffer.join('');
				
			}
		}
		
		
		window.Illume.Diff = {
			logic: 	null,
			
			init:	function() {
				this.logic = new window.diff_match_patch();
			},
		
			diff: 	function(s1, s2) {
				var diffs = this.logic.diff_main(s1, s2);
				this.cleanup(diffs);
				return diffs;
			},
			
			cleanup:	function(diffs) {
				this.logic.diff_cleanupSemantic(diffs);
			},
		
			formatDiffs:	function(diffs) {
				var html = [];
				var i = 0;
				for (var x = 0; x < diffs.length; x++) {
					var op = diffs[x][0];    
					var data = diffs[x][1];
					var text = data;
					switch (op) {
						case window.DIFF_INSERT:
							html[x] = '<ins>' + text + '</ins>';
							break;
						case window.DIFF_DELETE:
							html[x] = '<del>' + text + '</del>';
							break;
						case window.DIFF_EQUAL:
							html[x] = '' + text + '';
							break;
					}
					if (op !== window.DIFF_DELETE) {
						i += data.length;
					}
				}
				return html.join('');
			}
		
		}
		
		
		window.Illume.UI = {
			filter:	null,
			filterTag: null,
			byTagOption: null,
			passageListContent: null,
			passageViewer: null,
			generalOutput: null,
			
			init:	function() {
				this.filter = window.document.getElementById('filter');
				this.byTagOption = window.document.getElementById('byTagOption');
				this.passageListContent = window.document.getElementById('passageListContent');
				this.passageViewer = window.document.getElementById('passageViewer');
				this.generalOutput = window.document.getElementById('generalOutput');
			},
			
			filterChanged: function() {
				if (this.filter.value == 'byTag') {
					this.filterTag = null;
				}			
				this.updateList();
			},
			
			filterByTag:	function(tag) {
				this.filterTag = tag;
				this.filter.value = 'byTag';
				this.updateList();
			},
			
			updateFilterList:	function() {
				this.byTagOption.textContent = "By Tag...";
			},
			
			switchFilter:	function(value) {
				this.filter.value = value;
				this.updateList();
			},
			
			
			updateList:	function() {
				var matches = {};
				
				if (this.filter.value == 'unreviewed') {
					matches = Illume.Passages.findPassages(function(p) { return !p.reviewed;});
				} else if (this.filter.value == 'reviewed') {
					matches = Illume.Passages.findPassages(function(p) { return p.reviewed;});
				} else if (this.filter.value == 'changed') {
					matches = Illume.Passages.findPassages(function(p) { return p.changed;});
				} else if (this.filter.value == 'unchanged') {
					matches = Illume.Passages.findPassages(function(p) { return !p.changed;});
				} else if (this.filter.value == 'orphans') {
					matches = Illume.Passages.findPassages(function(p) { return (p.inboundLinks == 0)});
				} else if (this.filter.value == 'deadEnds') {
					matches = Illume.Passages.findPassages(function(p) { return (p.links == 0)});
				} else if (this.filter.value == 'passThroughs') {
					matches = Illume.Passages.findPassages(function(p) { return (p.links == 1 && p.inboundLinks == 1)});
				} else if (this.filter.value == 'all') {
					matches = Illume.Passages.getAll();
				} else if (this.filter.value == 'byTag') {
					if (!this.filterTag)
						this.filterTag = window.prompt("Show passages with tag:");
					if (!this.filterTag)
						return;
					
					this.byTagOption.textContent = "By Tag... [" + this.filterTag + "]";
					
					matches = Illume.Passages.findByTag(this.filterTag);
				}
	
				this.passageListContent.innerHTML = '';
				
				var buffer = [];

				for (var i in matches) {
					buffer.push("<span onclick=\"window.Illume.UI.showPassage('", matches[i].id, "');\">");
					if (matches[i].reviewed) {
						buffer.push('<div class="flag reviewed">R</div>');
					}
					if (matches[i].changed) {
						buffer.push('<div class="flag changed">C</div>');
					}
					buffer.push(matches[i].name);
					buffer.push("</span>");
				}	
				
				this.passageListContent.innerHTML = buffer.join('');
				
				this.updateFooter();
			},
			
			updateFooter:	function() {
				var footerLeft = window.document.getElementById('footerLeft');
				var footerRight = window.document.getElementById('footerRight');
			
				var reviewed = Illume.Passages.countPassages(function(p) { return p.reviewed;});
				var changed = Illume.Passages.countPassages(function(p) { return p.changed;});
				var total = Illume.Passages.passageCount;
				var remaining = total - reviewed;
				var reviewedPercentage = Math.ceil((reviewed / total) * 100);
				
				var buffer = [];
			
				if (remaining > 0) {
					buffer.push(reviewed, ' reviewed, ');
					buffer.push(remaining, ' remaining');
					buffer.push(" (");
				}
				buffer.push(reviewedPercentage, '% reviewed');
				if (remaining > 0) {
					buffer.push(')');
				}
			
				footerLeft.innerHTML = buffer.join('');
								
				buffer = [];

				if (changed > 0) {
					buffer.push(changed);
					buffer.push(' changed <input type="button" id="footerChangeListButton" value="Show Change List" onclick="Illume.viewChangeList()">');
				}
			
				footerRight.innerHTML = buffer.join('');
				
				
				
			},
			
			showGeneralOutput:	function(title, content) {
				var header = window.document.getElementById('generalTitle');
				var body = window.document.getElementById('generalContent');
				
				header.innerHTML = title;
				body.innerHTML = content;
				
				generalOutput.style.display = 'block';
				passageViewer.style.display = 'none';
			},
			
			showPassage:	function(id) {
				var p = Illume.Passages.getPassage(id);
				
				if (!p) {
					alert(id + ' not found');
					return;
				}
				
				window.document.getElementById("passageTitle").textContent = p.name;
				
				var tagContainer = window.document.getElementById("passageTags");
				
				tagContainer.innerHTML = '';
				
				var buffer = [];
				for (var i in p.tags) {
					if (p.tags[i]) {
						buffer.push("<span class=\"tag\" onclick=\"window.Illume.UI.filterByTag('");
						buffer.push(p.tags[i]);
						buffer.push("');\">");
						buffer.push(p.tags[i]);
						buffer.push("</span>");
					}
				}
				
				tagContainer.innerHTML = buffer.join('');

				Illume.Editor.editPassage(id);
				
				generalOutput.style.display = 'none';
				passageViewer.style.display = 'block';
				
			}
			
					
		}

		
		window.Illume.Editor = {
			editor:	null,
			currentPassageID: null,
			currentPassage: null,
			changeViewer: null,
			controls: null,
			changesShown: false,
			
			init:	function() {
				this.editor = window.document.getElementById('editor');
				this.controls = window.document.getElementById('passageControls');
				this.changeViewer = window.document.getElementById('changeViewer');
				
				this.editor.onchange = this.changeHandler;
				this.editor.onkeyup = this.inputHandler;
			},
			
			editPassage:	function(id) {
				this.currentPassageID = id;
				this.currentPassage = Illume.Passages.getPassage(id);
				
				this.editor.value = this.currentPassage.content;
				this.updateControls();
			},

			setReviewedHandler:	function(isReviewed) {
				Illume.Editor.setReviewed(isReviewed);
			},
			
			setReviewed:	function(isReviewed) {
				if (this.currentPassage.reviewed != isReviewed) {
					this.currentPassage.reviewed = isReviewed;
					this.updateControls();
					Illume.UI.updateList();
				}
			},
			
			revert:	function() {
				this.currentPassage.content = this.currentPassage.originalContent;
				this.currentPassage.changed = false;
				this.editPassage(this.currentPassageID);
				Illume.UI.updateList();
				this.hideChanges();
			},
			
			updateControls:	function() {
				var c = window.document.getElementById('dirtyControls');
				var r = window.document.getElementById('reviewedControls');
				var ur = window.document.getElementById('unreviewedControls');

				c.style.display = (this.currentPassage.changed) ? 'inline-block' : 'none';
				r.style.display = (this.currentPassage.reviewed) ? 'inline-block' : 'none';	
				ur.style.display = (!this.currentPassage.reviewed) ? 'inline-block' : 'none';	
				
				this.currentPassage.changed ? this.showChanges() : this.hideChanges();
			},

			showChanges: function() {
				this.updateChangeViewer(true);
				this.updateChangeDiffs();
			},
			
			hideChanges:	function() {
				this.updateChangeViewer(false);
			},
			
			toggleChanges:	function() {
				this.updateChangeViewer(!this.changesShown);			
			},
			
			updateChangeViewer:	function(shown) {
				this.changeViewer.style.display = (shown ? 'block' : 'none');
				//this.editor.style.bottom = (shown ? '300px' : '0px');   //DEBUG
				window.document.getElementById('editorCorral').style.bottom = (shown ? '300px' : '0px');
				
				this.changesShown = shown;
				this.updateChangeDiffs();
			},
			
			updateChangeDiffs:	function() {
				if (this.changesShown) {
					var p = this.currentPassage;
					var diffs = window.Illume.Diff.diff(Illume.encodeEntities(p.originalContent), Illume.encodeEntities(p.content));
					this.changeViewer.innerHTML = window.Illume.Diff.formatDiffs(diffs);
				}
			},
			
			updatePassage:	function() {
				this.currentPassage.content = this.editor.value;			
			},

			inputHandler:	function() {
				if (!Illume.Editor.currentPassage.changed) {
					Illume.Editor.currentPassage.changed = true;
					Illume.UI.updateList();
				}
				Illume.Editor.updatePassage();
				Illume.Editor.updateControls();				
				Illume.Editor.updateChangeDiffs();
			},
			
			changeHandler:	function() {
				Illume.Editor.updatePassage();
				Illume.Editor.updateControls();
				Illume.Editor.updateChangeDiffs();
			}
			

		}
		
		
		window.Illume.Story = {
			storyData:	null,
			storyName:	'{{STORY_NAME}}',
			storyFormat: '',
			startPassage: 1,
			stats: {},
			wordCount: 0,
			tags: {},
			
			init:	function() {
				this.loadStoryData();
			},
	
			loadStoryData:	function() {
				var storyDataElements = window.document.getElementsByTagName("tw-storydata");
				if (storyDataElements.length > 0) {
					this.storyData = storyDataElements[0];
					this.storyFormat = this.storyData.getAttribute("format");
					this.startPassage = this.storyData.getAttribute("startnode");
				}
			},
			
			compileStats:	function() {
				var p;
				
				var s = {
					format: this.storyFormat,
					passageCount: Illume.Passages.passageCount,
					wordCount: this.wordCount,
					orphans: Illume.Passages.countPassages( function(p) { return (p.inboundLinks < 1); }),
					deadEnds: Illume.Passages.countPassages( function(p) { return (p.links < 1); }),
					'pass-throughs': Illume.Passages.countPassages( function(p) { return (p.links == 1 && p.inboundLinks == 1); }),
					
					averageLinks: Math.floor(Illume.Passages.averageConnectivity * 100) / 100 ,
					averageWords: Math.floor(Illume.Passages.averageLength * 100) / 100
					
				};
							
				this.stats = s;
			},
			
			generateStorySummary:	function() {
				var result = Object.create(this.stats);
				
				result['format'] = result.format;
				result.orphans = {
					illumeLink:	"Illume.UI.switchFilter('orphans');",
					value:	result.deadEnds
				}
				result.deadEnds = {
					illumeLink:	"Illume.UI.switchFilter('deadEnds');",
					value:	result.deadEnds
				}
				result['pass-throughs'] = {
					illumeLink:	"Illume.UI.switchFilter('passThroughs');",
					value:	result['pass-throughs']
				}
				result.passageCount = {
					illumeLink:	"Illume.UI.switchFilter('all');",
					value:	result.passageCount
				}
				
				return result;
			},
			
			getTagSummary:	function() {
				var results = {
					"header.Tag": "Occurences"
				}
				var label;
				
				for (var t in this.tags) {
					label = "<span class=\"tag\" onclick=\"window.Illume.UI.filterByTag('" + t + "');\">" + t + "</span>";
					results[label] = this.tags[t];
				}
				
				return results;
			}
		
		}
		
		
		window.Illume.Passages = {
			passages: 	[],
			linkCount:	{},
			deadLinks:	[],
			passageCount: 0,
			averageConnectivity: 0,
			averageLength: 0,
			
			basePassage: {
				id:	-1,
				name: "Undefined",
				tags: [],
				links: 0,
				inboundLinks: 0,
				connections: 0,
				sugarcubeMacros: 0,
				harloweMacros: 0,
				harloweHooks: 0,
				wordCount: 0,
				content: '',
				originalContent: '',
				reviewed: false,
				changed: false
			},
			
			
			init: 	function() {
				this.loadPassages();
			},
			
			getPassage: function(id) {
				return this.passages[id];
			},

			getAll:	function() {
				return this.passages.slice();
			},
			
			findByTag:	function(tag) {
				var results = [];
				var p;
				
				results.length = 0;
				for (var i = 0; i < this.passages.length; i++) {
					p = this.passages[i];
					if (p && p.tags.indexOf(tag) > -1) {
						results.push(p);
					}
				}
				return results;
			},
			
			findByName:	function(name) {
				var p;
				
				for (var i in this.passages) {
					p = this.passages[i];
					if (p && p.name == name) {
						return p;
					}
				}
				return null;
			},

			findPassages:	function(checkFunction) {
				var p;
				var results = [];

				if (!checkFunction || typeof(checkFunction) != "function") {
					return -1;
				}

				for (var i in this.passages) {
					p = this.passages[i];
					
					if (checkFunction(p)) {
						results.push(p);
					}
				}
				
				return results;
			},
			
			countPassages:	function(checkFunction) {
				var results = this.findPassages(checkFunction);
				if (!results)
					return 0;
				else
					return results.length;
			},
			
			loadPassages: function() {
				var passageElements = window.document.getElementsByTagName("tw-passagedata");
				var e;
				var p;
				var tagString;
				
				linkCount = {};
				
				var matchers = {
					links:					/[^`]\\[{2}(.*)\\]{2}(?=[^`])/g,
					sugarcubeMacros:		/\\<{2}.*\\>{2}/g,
					harloweMacros:			/[^`]\\([^\W]*:.*\\)(?=[^`])/g,
					harloweHooks:			/[^`\\[]\\[[^\\[\\]]*\\](?=[^`\\]])/g
				};
				
				this.passages.length = 0;
				for (var i = 0; i < passageElements.length; i++) {
					p = Object.create(this.basePassage);			
					e = passageElements[i];
					
					tagString = e.getAttribute("tags").trim();
					
					if (!tagString || tagString.length < 1)
						p.tags = [];					
					else 
						p.tags = tagString.split(" ");
					
					if (p.tags.indexOf("illumeIgnore") > -1) {
						continue;
					}

					if (p.tags.indexOf("illumeReviewed") > -1) {
						p.reviewed = true;
					}
					
					p.id = e.getAttribute("pid");
					p.name = e.getAttribute("name");
					p.content = e.textContent;
					p.originalContent = e.textContent;
					p.strippedContent = e.textContent;
					
					for (var j in matchers) {
						p[j] = (p.content.match(matchers[j]) || []).length;
					}
					
					if (p.harloweMacros > 0)
						p.strippedContent = p.strippedContent.replace(matchers.harloweMacros, '');
					
					
					if (p.sugarcubeMacros > 0)
						p.strippedContent = p.strippedContent.replace(matchers.sugarcubeMacros, '');
					
					var re, match, destination;
					
					re = matchers.links;
					re.lastIndex = 0;
					
					var destinations = [];
					
					
					while ((match = re.exec(' ' + p.content + ' ')) !== null) {
						destination = match[1];
						
						if (destination.indexOf("->") > -1) {
							//harlowe right link
							destination = destination.substring(destination.indexOf("->") + 2);
						} else if (destination.indexOf("<-") > -1) {
							//harlowe left link
							destination = destination.substring(0, destination.indexOf("<-"));
						} else if (destination.indexOf("|") > -1) {
							//sugarcube link
							destination = destination.substring(destination.indexOf("|") + 1);
						}
						
						if (destinations.indexOf(destination) < 0)
							destinations.push(destination);
					}
					

					for (var d in destinations) {
						//alert('adding a link from ' + p.name + ' to ' + destinations[d]);
						if (linkCount[destinations[d]])
							++linkCount[destinations[d]];
						else
							linkCount[destinations[d]] = 1;
					}
						
					p.wordCount = p.strippedContent.trim().replace(/\\s+/g, ' ').split(' ').length;
					
					this.passages[p.id] = p;
				}
				
				
				var killList = [];
				var connectivityTotal = 0;
				this.passageCount = 0
				Illume.Story.wordCount = 0;
				Illume.Story.tags = {};
				
				for (var i in this.passages) {
					p = this.passages[i];
					p.inboundLinks = (linkCount[p.name] || 0);
					p.connections = p.links + p.inboundLinks;
					killList.push(p.name);
				
					Illume.Story.wordCount += p.wordCount;
					connectivityTotal += p.connections;
					++this.passageCount;
					
					for (var t in p.tags) {
						if (!Illume.Story.tags[p.tags[t]])
							Illume.Story.tags[p.tags[t]] = 1;
						else
							++Illume.Story.tags[p.tags[t]];
					}
				}
				
				for (var n in killList) {
					delete(linkCount[killList[n]]);
				}
				
				this.averageLength = Illume.Story.wordCount / this.passageCount;
				this.averageConnectivity = connectivityTotal / this.passageCount;
				
				this.deadLinks = linkCount;
			},
	
			generateSummary:	function() {
				var ps = this.passages.slice();
				var results = {};
				var p;
				
				ps.sort(function(a,b) {
					if (a.connections < b.connections)
						return 1;
					if (a.connections > b.connections)
						return -1;
					return 0;
				});
				
				results["header.Passage"] = [
					'Length',
					'Links (In/Out)'
				];
				
				for (var i in ps) {
					p = ps[i];
					results[p.name] = {
						illumeLink:	"Illume.UI.showPassage('" + p.id + "');",
						wordCount: p.wordCount,
						connections: p.connections + " (" + p.inboundLinks + "/" + p.links + ")"
					};
				}
				
				return results;				
			},

			generateReviewSummary:	function() {
				var result = {};
				var reviewed = this.countPassages(function(p) { return p.reviewed;});
				var changed = this.countPassages(function(p) { return p.changed;});
				
				result['totalPassages'] = {
					illumeLink:	"window.Illume.UI.switchFilter('all');",
					value: this.passageCount
				}
				result['changed'] = {
					illumeLink:	"window.Illume.UI.switchFilter('changed');",
					value: changed
				};
				result['reviewed'] = {
					illumeLink:	"window.Illume.UI.switchFilter('reviewed');",
					value:	reviewed
				};
				result['reviewCompleted'] = {
					illumeLink:	"window.Illume.UI.switchFilter('unreviewed');",
					value:	Math.ceil(reviewed / this.passageCount * 100) + '%'
				};
				

			
				return result;
			}

		}
		
		
		window.Illume.Entweedle = {
			
			export: function() {
				var output = window.document.getElementById("output");
				var buffer = [];

				var storyData = window.document.getElementsByTagName("tw-storydata");
				if (storyData) {
					buffer.push(this.buildPassage("StoryTitle","",storyData[0].getAttribute("name")));
				}
				var userScript = window.document.getElementById("twine-user-script");
				if (userScript) {
					buffer.push(this.buildPassage("UserScript","script",userScript.innerHTML));
				}
				
				var userStylesheet = window.document.getElementById("twine-user-stylesheet");
				if (userStylesheet) {
					buffer.push(this.buildPassage("UserStylesheet","stylesheet",userStylesheet.innerHTML));
				}

				var passages = window.document.getElementsByTagName("tw-passagedata");
				for (var i = 0; i < passages.length; i++) {
					buffer.push(this.buildPassageFromElement(passages[i]));
				}
				
				return buffer.join('');
			},
		
			
			buildPassageFromElement: function(passage) {
				var name = passage.getAttribute("name");
				if (!name) {
					name = "Untitled Passage";
				}
				var tags = passage.getAttribute("tags");
				var content = passage.textContent;
				
				return this.buildPassage(name, tags, content);
			},
	
			buildPassage: function(title, tags, content) {
				var result = [];
				
				result.push(":: ",title);
				if (tags) {
					result.push("[",tags,"]");
				}
				result.push("\r\n", this.scrub(content),"\r\n\r\n");
				
				return result.join('');
			},
			
			scrub: function(content) {
				content = content.replace(/^::/gm, " ::");
				return content;
			}
		}			
	

		window.Illume.init();
	}
}
